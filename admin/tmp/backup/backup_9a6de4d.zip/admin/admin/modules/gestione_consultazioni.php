<?php
require_once '../includes/check_access.php';
$inizioNoGenere = strtotime('2025/06/30');
global $genere;
$tipi=elenco_tipi();
?>

<section class="content">
  <div class="container-fluid">
    <h2><i class="fas fa-vote-yea"></i> Gestione Consultazioni</h2>

    <!-- FORM -->
    <div class="card mb-4">
      <div class="card-header bg-primary text-white">
        <h3 class="card-title" id="form-title">Aggiungi Consultazione</h3>
      </div>
      <div class="card-body">
        <form id="consultazioneForm"  onsubmit="aggiungiConsultazione(event)">
          <input type="hidden" name="id_cons_gen" id="id_cons_gen">
          <div class="form-row">
            <div class="form-group col-md-3">
              <label for="tipo">Tipo*</label>
              <select class="form-control" id="tipo" name="tipo" onchange="selezionaInput()" required>
                <option value="">Seleziona...</option>
				<?php foreach($tipi as $key=>$val) { ?>
                <option value="<?= $val['tipo_cons'] ?>"><?= $val['descrizione'] ?></option>
				<?php } ?>
              </select>
            </div>
            <div class="form-group col-md-5">
              <label for="denominazione">Denominazione*</label>
              <input type="text" class="form-control" id="denominazione" name="denominazione" required>
            </div>
            <div class="form-group col-md-2">
              <label for="data_inizio">Data Inizio*</label>
              <input type="date" class="form-control" id="data_inizio" name="data_inizio" required onchange="selezionaInput()">
            </div>
            <div class="form-group col-md-2">
              <label for="data_fine">Data Fine*</label>
              <input type="date" class="form-control" id="data_fine" name="data_fine" required>
            </div>
          </div>

          <div class="form-group" id="divlink">
            <label for="link">Link DAIT Trasparenza</label>
            <input type="url" class="form-control" id="link" name="link">
		  </div>
      <div class="form-row">		  
		    <div class="form-group col-12 col-sm-6 col-md-2" id="divpreferenze">
			  <label for="preferenze">Preferenze</label>
			  <input type="number" class="form-control" id="preferenze" name="preferenze" value="1" min="1" step="1" required>
			</div>

		  <?php $row = elenco_leggi(); ?>
		  <div class="form-group col-12 col-sm-6 col-md-4" id="divlegge">
			<label for="id_conf">Legge elettorale</label>
			<select class="form-control" id="id_conf" name="id_conf">
				<option value="" >Seleziona...</option>
			  <?php $i=0; foreach($row as $val) { ?>
				<option value="<?= $val['id_conf'] ?>"><?= $val['descrizione'] ?></option>
			  <?php } ?>
			</select>				
		  </div>
			<div class="form-group col-12 col-sm-6 col-md-2" id="divfascia">
				<label for="id_fascia">Abitanti</label>
				<select class="form-control" id="id_fascia" name="id_fascia">
					<option value="">Seleziona...</option>
					<?php
					$fasce = elenco_fasce(1);  // chiami la funzione
					$precedente = 0;

					foreach ($fasce as $riga) {

						$id = $riga['id_fascia'];
						$abitanti = (int)$riga['abitanti'];

						// ultima fascia → Oltre 1000000
						if ($id == count($fasce)) {
							$testo = 'Oltre ' . $precedente;
						} else {
							$testo = $precedente . ' - ' . $abitanti;
						}

						echo '<option value="'.$id.'">'.$testo.'</option>';

						// aggiornamento per la fascia successiva
						$precedente = $abitanti + 1;
					}
					?>
				</select>
			</div>

		  <div class="form-group col-12 col-sm-6 col-md-2" id="divstato">
			<label for="chiusa">Stato</label>
			<select class="form-control" id="chiusa" name="chiusa">
			  <option value="0">Attiva</option>
			  <option value="1">Chiusa</option>
			  <option value="2">Nulla</option>
			</select>				
		  </div>
		  <div class="form-group col-12 col-sm-6 col-md-2" id="divdisgiunto">
			<label for="disgiunto">Voto disgiunto</label>
			<select class="form-control" id="disgiunto" name="disgiunto">
			  <option value="0">No</option>
			  <option value="1">Si</option>
			</select>				
		  </div>
		  <div class="form-group col-12 col-sm-6 col-md-2" id="divsologruppo">
			<label for="solo_gruppo">Ai soli gruppi</label>
			<select class="form-control" id="solo_gruppo" name="solo_gruppo">
			  <option value="0">No</option>
			  <option value="1">Si</option>
			</select>				
		  </div>
		  <div class="form-group col-12 col-sm-6 col-md-3" id="divvismf">
			<label for="vismf">Affluenze per genere</label>
			<select class="form-control" id="vismf" name="vismf">
			  <option value="0">No</option>
			  <option value="1">Si</option>
			</select>				
		  </div>
		  <div class="form-group col-12 col-sm-6 col-md-2" id="divproiezione">
			<label for="proiezione">Proiezione consiglio</label>
			<select class="form-control" id="proiezione" name="proiezione">
			  <option value="0">No</option>
			  <option value="1">Si</option>
			</select>				
		  </div>
		</div>


          <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="preferita" name="preferita">
            <label class="form-check-label" for="preferita">Consultazione predefinita</label>
			
          </div>

          <button type="submit" class="btn btn-success" id="submitBtn">Aggiungi Consultazione</button>
          <button type="button" class="btn btn-secondary" onclick="resetFormConsultazione()">Annulla</button>
        </form>
      </div>
    </div>

    <!-- LISTA -->
    <div class="card">
      <div class="card-header bg-secondary text-white">
        <h3 class="card-title">Lista Consultazioni</h3>
      </div>
      <div class="card-body table-responsive">
        <table class="table table-bordered table-hover" id="consultazioniTable">
          <thead>
            <tr>
              <th style="width:30px;"></th> <!-- colonna stella senza titolo -->
              <th>Tipo</th>
              <th>Denominazione</th>
              <th>Data Inizio</th>
              <th>Data Fine</th>
              <th>Azioni</th>
            </tr>
          </thead>
          <tbody id="risultato"><?php include('elenco_consultazioni.php'); ?>	</tbody>
        </table>
      </div>
    </div>
  </div>
</section>
<!-- =======================
     MODAL ELIMINA CONSULTAZIONE
     ======================= -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">

      <!-- HEADER -->
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="confirmDeleteLabel">
          <i class="fas fa-exclamation-triangle me-2"></i>
          Conferma eliminazione consultazione
        </h5>
        <button type="button" class="close" data-dismiss="modal">
          <span>&times;</span>
        </button>
      </div>

      <!-- BODY -->
      <div class="modal-body">

        <div class="alert alert-danger">
          <strong>ATTENZIONE</strong><br>
          Questa azione non può essere annullata!
        </div>

        <p>Sei sicuro di voler eliminare la consultazione: <strong id="deleteDenominazione"></strong>?</p>

        <form id="formDeleteConsultazione">
          <!-- CHECKBOX ELIMINA SOLO DATI -->
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" id="deleteOnlyData">
            <label class="form-check-label" for="deleteOnlyData">
              Elimina solo i dati associati (lascia la consultazione)
            </label>
          </div>

          <!-- CHECKBOX CONFERMA -->
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="confirmDeleteCheck">
            <label class="form-check-label text-danger" for="confirmDeleteCheck">
              Confermo di voler procedere con l'eliminazione
            </label>
          </div>
        </form>

        <div id="deleteResult" class="mt-3"></div>

      </div>

      <!-- FOOTER -->
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulla</button>
        <button type="button"
                class="btn btn-danger"
                id="confirmDeleteBtn"
                disabled>
          <i class="fas fa-trash me-1"></i>Elimina
        </button>
      </div>

    </div>
  </div>
</div>


<script>
const dataInizioInput = document.getElementById("data_inizio");
const dataFineInput = document.getElementById("data_fine");

// Controllo quando cambia la data fine
dataFineInput.addEventListener("change", () => {
    if (dataInizioInput.value && dataFineInput.value) {
        const inizio = new Date(dataInizioInput.value);
        const fine = new Date(dataFineInput.value);

        if (fine < inizio) {
            alert("La data di fine non può essere precedente alla data di inizio!");
            dataFineInput.value = ""; // reset della data errata
            dataFineInput.focus();
        }
    }
});

function aggiungiConsultazione(e) {
    e.preventDefault();

	const denominazione = document.getElementById ( "denominazione" ).value
	const dataInizio = document.getElementById ( "data_inizio" ).value
	const dataFine = document.getElementById ( "data_fine" ).value
	const linkDait = document.getElementById ( "link" ).value
	const tipo = document.getElementById ( "tipo" ).value
	const preferita = document.getElementById ( "preferita" ).checked
	const id_cons_gen = document.getElementById ( "id_cons_gen" ).value
	const chiusa = document.getElementById ( "chiusa" ).value
	const id_conf = document.getElementById ( "id_conf" ).value
	const preferenze = document.getElementById ( "preferenze" ).value
	const id_fascia = document.getElementById ( "id_fascia" ).value
	const vismf = document.getElementById ( "vismf" ).value
	const solo_gruppo = document.getElementById ( "solo_gruppo" ).value
	const disgiunto = document.getElementById ( "disgiunto" ).value
	const proiezione = document.getElementById ( "proiezione" ).value

    // Crea un oggetto FormData e aggiungi il file
    const formData = new FormData();
    formData.append('funzione', 'salvaConsultazione');
    formData.append('id_cons_gen', id_cons_gen);
    formData.append('descrizione', denominazione);
    formData.append('data_inizio', dataInizio);
    formData.append('data_fine', dataFine);
    formData.append('link_dait', linkDait);
    formData.append('tipo', tipo);
    formData.append('preferita', preferita);
    formData.append('chiusa', chiusa);
    formData.append('id_conf', id_conf);
    formData.append('preferenze', preferenze);
    formData.append('id_fascia', id_fascia);
    formData.append('vismf', vismf);
    formData.append('solo_gruppo', solo_gruppo);
    formData.append('disgiunto', disgiunto);
    formData.append('proiezione', proiezione);
    formData.append('op', 'salva');

    // Invia la richiesta AJAX usando Fetch
    fetch('../principale.php', {
        method: 'POST',
        body: formData // FormData viene gestito automaticamente da Fetch per l'upload
    })
    .then(response => response.text()) // O .json() se il server risponde con JSON
    .then(data => {
		const myForm = document.getElementById('consultazioneForm');
        risultato.innerHTML = data; // Mostra la risposta del server
		myForm.reset();
		document.getElementById ( "id_cons_gen" ).value = ''
		document.getElementById ( "submitBtn" ).textContent = "Aggiungi Consultazione"
		document.getElementById("form-title").textContent = "Aggiungi Consultazione";
		aggiornaSelect();
    })
	

};


const deleteOnlyDataCheckbox = document.getElementById('deleteOnlyData');
const confirmDeleteCheckbox = document.getElementById('confirmDeleteCheck');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

let deleteId = null;

function deleteConsultazione(index) {
    deleteId = document.getElementById("id_cons_gen"+index).innerText;
    const denominazione = document.getElementById("descrizione"+index).innerText;
    document.getElementById("deleteDenominazione").textContent = denominazione;

    // reset checkbox
    deleteOnlyDataCheckbox.checked = false;
    confirmDeleteCheckbox.checked = false;
    confirmDeleteBtn.disabled = true;

    $('#confirmDeleteModal').modal('show');
}

// abilita il pulsante solo se la conferma è spuntata
confirmDeleteCheckbox.addEventListener('change', () => {
    confirmDeleteBtn.disabled = !confirmDeleteCheckbox.checked;
});


confirmDeleteBtn.addEventListener('click', function() {
    if(deleteId && confirmDeleteCheckbox.checked) { debugger
        const formData = new FormData();
        formData.append('funzione', 'salvaConsultazione');
        formData.append('id_cons_gen', deleteId);
        formData.append('op', deleteOnlyDataCheckbox.checked ? 'cancellaDati' : 'cancella');

        fetch('../principale.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById("risultato").innerHTML = data;
            $('#confirmDeleteModal').modal('hide');
            deleteId = null;
            aggiornaSelect();
        });
    }
});

  
   function editConsultazione(index) {
	document.getElementById ( "id_cons_gen" ).value = document.getElementById ( "id_cons_gen"+index ).innerText
	document.getElementById ( "denominazione" ).value = document.getElementById ( "descrizione"+index ).innerText
	document.getElementById ( "data_inizio" ).value = document.getElementById ( "data_inizio"+index ).value
	document.getElementById ( "data_fine" ).value = document.getElementById ( "data_fine"+index ).value
	document.getElementById ( "tipo" ).selectedIndex = document.getElementById ( "tipo_cons"+index ).innerText
	document.getElementById ( "link" ).value = document.getElementById ( "link_trasparenza"+index ).innerText
	document.getElementById ( "chiusa" ).selectedIndex = document.getElementById ( "chiusa"+index ).innerText
	document.getElementById ( "id_conf" ).selectedIndex = document.getElementById ( "id_conf"+index ).innerText - 1
	if(document.getElementById ( "preferita"+index ).innerText==1)
		document.getElementById ( "preferita" ).checked = true
	else
		document.getElementById ( "preferita" ).checked = false
	document.getElementById ( "preferenze" ).value = document.getElementById ( "preferenze"+index ).innerText
	document.getElementById ( "id_fascia" ).selectedIndex = document.getElementById ( "id_fascia"+index ).innerText -1
	document.getElementById ( "vismf" ).selectedIndex = document.getElementById ( "vismf"+index ).innerText
	document.getElementById ( "solo_gruppo" ).selectedIndex = document.getElementById ( "solo_gruppo"+index ).innerText
	document.getElementById ( "disgiunto" ).selectedIndex = document.getElementById ( "disgiunto"+index ).innerText
	document.getElementById ( "proiezione" ).selectedIndex = document.getElementById ( "proiezione"+index ).innerText

	document.getElementById ( "submitBtn" ).textContent = "Salva modifiche"
	document.getElementById("form-title").textContent = "Modifica Consultazione";
//	document.getElementById("riga"+index).style.display = 'none' 
	selezionaInput()
  }
  
function selezionaInput() {
	const tipo = document.getElementById("tipo").value;
	const dataInizioInput = document.getElementById("data_inizio").value;
	const inizioNoGenere = new Date("2025-06-30"); // data limite
	let dataInizio = dataInizioInput ? new Date(dataInizioInput) : null;

	// Gestione visibilità in base al tipo
	document.getElementById("divproiezione").style.display = 'none';
	document.getElementById("id_conf").required = false;
	document.getElementById("id_fascia").required = false;
	switch(tipo) {
		case "1":
		case "9":
		case "10":
		case "11":
		case "12":
		case "15":
		case "16":
		case "17":
		case "18":
		case "19":
			document.getElementById("divpreferenze").style.display = 'block';
			document.getElementById("divlink").style.display = 'block';
			document.getElementById("divsologruppo").style.display = 'block';
			document.getElementById("divdisgiunto").style.display = 'block';
			document.getElementById("divlegge").style.display = 'none';
			document.getElementById("divfascia").style.display = 'none';
			break;
		case "6":
		case "7":
		case "8":
		case "14":
			document.getElementById("divpreferenze").style.display = 'block';
			document.getElementById("divlink").style.display = 'block';
			document.getElementById("divsologruppo").style.display = 'none';
			document.getElementById("divdisgiunto").style.display = 'none';
			document.getElementById("divfascia").style.display = 'none';
			document.getElementById("divlegge").style.display = 'none';
			break;
		case "2":
		case "5":
		case "13":
			document.getElementById("divproiezione").style.display = 'none';
			document.getElementById("divpreferenze").style.display = 'none';
			document.getElementById("divlink").style.display = 'none';
			document.getElementById("divsologruppo").style.display = 'none';
			document.getElementById("divdisgiunto").style.display = 'none';
			document.getElementById("divfascia").style.display = 'none';
			document.getElementById("divlegge").style.display = 'none';
			break;
		case "3":
		case "4":
			document.getElementById("divproiezione").style.display = 'block';
			document.getElementById("divpreferenze").style.display = 'block';
			document.getElementById("divlink").style.display = 'block';
			document.getElementById("divsologruppo").style.display = 'block';
			document.getElementById("divdisgiunto").style.display = 'block';
			document.getElementById("divfascia").style.display = 'block';
			document.getElementById("divlegge").style.display = 'block';
			document.getElementById("id_conf").required = true;
			document.getElementById("id_fascia").required = true;
//			idConf.required = true;
			break;
	}

	// Controllo affluenze per genere in base alla data
	if(dataInizio && dataInizio > inizioNoGenere) {
		document.getElementById("divvismf").style.display = 'none';
	} else {
		document.getElementById("divvismf").style.display = 'block';
	}
}


function resetFormConsultazione() {
    const form = document.getElementById('consultazioneForm');
    form.reset(); // reset base dei campi
    
    // Ripulisce campo nascosto
    document.getElementById('id_cons_gen').value = '';

    // Ripristina testo bottone
    document.getElementById('submitBtn').textContent = "Aggiungi Consultazione";

    // Ripristina valori di select al primo elemento
    document.getElementById('tipo').selectedIndex = 0;
    document.getElementById('chiusa').selectedIndex = 0;
    document.getElementById('id_conf').selectedIndex = 0;
	document.getElementById("id_conf").required = false;
    document.getElementById('id_fascia').selectedIndex = 0;
	document.getElementById("id_fascia").required = false;
    document.getElementById('vismf').selectedIndex = 0;
    document.getElementById('solo_gruppo').selectedIndex = 0;
    document.getElementById('disgiunto').selectedIndex = 0;
    document.getElementById('proiezione').selectedIndex = 0;

    // Ripristina checkbox
    document.getElementById('preferita').checked = false;

    // Ripristina valori input text/url
    document.getElementById('denominazione').value = '';
    document.getElementById('data_inizio').value = '';
    document.getElementById('data_fine').value = '';
    document.getElementById('link').value = '';
    document.getElementById('preferenze').value = '1';

    // Ripristina visibilità div dinamici allo stato iniziale
    document.getElementById('divpreferenze').style.display = 'block';
    document.getElementById('divlink').style.display = 'block';
    document.getElementById('divsologruppo').style.display = 'block';
    document.getElementById('divdisgiunto').style.display = 'block';
    document.getElementById('divfascia').style.display = 'block';
    document.getElementById('divlegge').style.display = 'block';
    document.getElementById('divproiezione').style.display = 'block';
}

function aggiornaSelect() {
        const selectCons = new FormData();
    selectCons.append('funzione', 'menuConsultazione');
//    formData.append('id_cons_gen', id_cons_gen);
    fetch('../principale.php', {
        method: 'POST',
        body: selectCons
    })
    .then(response => response.text())
    .then(data => {
                var elementExists = document.getElementById("consultazione-mobile");
                if(elementExists!== null)
					document.getElementById ("consultazione-mobile").innerHTML = data;
                var elementExists = document.getElementById("consultazione-desktop");
                if(elementExists!== null)
					document.getElementById ("consultazione-desktop").innerHTML = data;
    })

}

function scrollToFormTitle() {
    const target = document.getElementById('form-title');
    if (target) {
        target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}
</script>